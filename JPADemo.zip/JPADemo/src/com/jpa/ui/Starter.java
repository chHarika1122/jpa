package com.jpa.ui;

import java.time.LocalDate;

import com.jpa.dao.EmployeeDAO;
import com.jpa.dao.EmployeeJpqlDao;
import com.jpa.model.Employee;

public class Starter {

	public static void main(String[] args) {
		Employee emp= new Employee();
		/*Employee emp= new Employee();
		emp.setCity("chennai");
		//emp.setEmpId(1000);     //when identity auto is used, this should not be specified
		emp.setEmpName("john");
		emp.setSalary(20000);
		//emp.setDoj(LocalDate.now());
		EmployeeDAO e = new EmployeeDAO();
		e.addEmployee(emp);*/
		//e.updateEmployee();
		//e.deleteEmployee();
		//e.getEmployee();
		EmployeeJpqlDao e = new EmployeeJpqlDao();
		e.getEmployees();
		System.out.println("Program ends");
	}


	//primary key auto_increment
}

//"jdbc:mysql://localhost:3306/demodb","root","root"
