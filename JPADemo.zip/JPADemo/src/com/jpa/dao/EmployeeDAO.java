package com.jpa.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.jpa.model.Employee;

public class EmployeeDAO {
public void addEmployee(Employee e) {
	EntityManagerFactory emf =null;
			EntityManager em = null;
	try {
		
	//jpa logic to perform insert operation
	    emf = Persistence.createEntityManagerFactory("JPADemo");   // helps to connect with db
        em = emf.createEntityManager();  //factory with manager to perform the methods
	em.getTransaction().begin();//get the factory
	em.persist(e);//
	em.getTransaction().commit();//commit the factory
	
	}catch(Exception ex) {
		
		ex.printStackTrace();
		
	} finally {
		
		if(em!=null && emf!=null)
			em.close();
		emf.close();
		
	}

	
}
public void getEmployee() {
	EntityManagerFactory emf =null;
	EntityManager em = null;
	try {
		
		//jpa logic to perform insert operation
		    emf = Persistence.createEntityManagerFactory("JPADemo");   // helps to connect with db
	        em = emf.createEntityManager();  //factory with manager to perform the methods
		
		Employee emp=em.find(Employee.class, 1002);
		if(emp!=null) {            //When given data is not present in the table then if statement is used
			System.out.println(emp.getCity());
			System.out.println(emp.getEmpName());
		}
		else {
			System.out.println("emp details are not given");
		}
		
		}catch(Exception ex) {
			
			ex.printStackTrace();
			
		} finally {
			
			if(em!=null && emf!=null)
				em.close();
			emf.close();
			
		}
		
		
	}

public void updateEmployee() {
	
	EntityManagerFactory emf =null;
	EntityManager em = null;
try {

//jpa logic to perform insert operation
emf = Persistence.createEntityManagerFactory("JPADemo");   // helps to connect with db
em = emf.createEntityManager();  //factory with manager to perform the methods

Employee emp=em.find(Employee.class, 1002);
if(emp!=null) {            //When given data is not present in the table then if statement is used
	em.getTransaction().begin();//get the factory
	emp.setCity("adsa");
	emp.setEmpName("gdfha");
	em.getTransaction().commit();
}
else {
System.out.println("emp details are not given");
}

}catch(Exception ex) {

ex.printStackTrace();

} finally {

if(em!=null && emf!=null)
	em.close();
emf.close();

}


}

public void deleteEmployee() {
	EntityManagerFactory emf =null;
	EntityManager em = null;
try {

//jpa logic to perform insert operation
emf = Persistence.createEntityManagerFactory("JPADemo");   // helps to connect with db
em = emf.createEntityManager();  //factory with manager to perform the methods
Query query = em.createQuery("SELECT DISTINCT e.empId FROM Employee e");

Employee emp=em.find(Employee.class, 1001);
if(emp!=null) {            //When given data is not present in the table then if statement is used
	em.getTransaction().begin();//get the factory
	em.remove(emp);
	em.getTransaction().commit();
}
else {
System.out.println("emp details are not given");
}

}catch(Exception ex) {

ex.printStackTrace();

} finally {

if(em!=null && emf!=null)
	em.close();
emf.close();

}


}
}




