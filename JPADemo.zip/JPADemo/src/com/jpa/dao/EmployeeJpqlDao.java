package com.jpa.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.jpa.model.Employee;

public class EmployeeJpqlDao {

	public void getEmployees() {
		EntityManagerFactory emf =null;
		EntityManager em = null;
		try {
			
			//jpa logic to perform insert operation
			    emf = Persistence.createEntityManagerFactory("JPADemo");   // helps to connect with db
		        em = emf.createEntityManager();  //factory with manager to perform the methods
			/*Query q=em.createQuery("select e from Employee e"); //employee is the entity class name
			List<Employee> list=q.getResultList();     //list with all the rows are displayed
*/			/*q.executeUpdate();
			q.getSingleResult();//exactly one row otherwise throws exception
*/		/*	for(Employee employee:list) {
	System.out.println(employee.getEmpId());
	System.out.println(employee.getEmpName());
}*/
		        Query q=em.createNamedQuery("getemp");
				List<Employee>list=q.getResultList();
				for(Employee employee:list) {
					System.out.println(employee.getEmpName());
				}
			
		        
		        
			}catch(Exception ex) {
				
				ex.printStackTrace();
				
			} finally {
				
				if(em!=null && emf!=null)
					em.close();
				emf.close();
				
			}
			
			//select e from Employee e where e.salary>56587
	      //int salary=34112   
		//salary>:sal	
		//q.setParameter("sal",53632)
		//for positional paramter use -> ?1
		//q.setParameter(1,53632)
		
		
		//TypedQuery<Employee> q=em.createQuery("select e from Employee e where e.salary>:sal", Employee.class)
		//q.setParameter(1,53632)
	    
		////TypedQuery<String> q=em.createQuery("select e.empName from Employee e where e.salary>:sal", String.class)
		
		//Query q3=em.createQuery("select count(*) from employee e");
		//Long l=(Long)q3.getSingleresult();
		  //syso("no of rec"+l);
		
		
		//em.gettranscation.begin
		//Query q4=em.creatQuery("update Employee set salary=sal+100")
		//int rows=q4.executeUpdate();
		//syso(rows);
	
		
		
	}
	}

