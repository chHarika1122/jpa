package com.jpa.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

//sequence-supported by few db (mysql doesn't support) , auto, identity, table

@Entity
//@Table(name="employee")//to map the table 

@NamedQuery(name="getemp",query="select e from Employee e")
//@NamedQueries() -> set of queries can be given here

public class Employee {
@Id
//@Column(name="salary")
@GeneratedValue(strategy=GenerationType.IDENTITY)
//@GeneratedValue(strategy=GenerationType.AUTO)//if db supports this statement then auto function is done
	private Integer empId;
	private String empName;
	private Integer salary;
	private String city;
	//@Column(name="doj")// when columns mismatching occurs wrt names
	//private LocalDate doj;
	//@Transient //it will not involve this variable 
	//private Integer servicePeriod;
	/*public LocalDate getDoj() {
		return doj;
	}
	public void setDoj(LocalDate doj) {
		this.doj = doj;
	}
*/	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public Integer getSalary() {
		return salary;
	}
	public void setSalary(Integer salary) {
		this.salary = salary;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
}
