package com.jpa.ui;

import java.util.Scanner;

import com.jpa.bean.Author;
import com.jpa.service.AuthorServiceImpl;

public class Starter {
	public static void show() {
		System.out.println("1.Insert Author");
		System.out.println("2.Update Author");
	    System.out.println("Enter the choice:");
	}
	
	public static void main(String[] args) {
		Author aut=new Author();
		AuthorServiceImpl asi=new AuthorServiceImpl();
		Scanner sc=new Scanner(System.in);
		int choice;
		show();
		while(true) {
			choice=sc.nextInt();
			switch(choice) {
			case 1:
 
              		System.out.println("Enter the author details:");
	             	System.out.println("Enter ID: ");
		            int aid=sc.nextInt();
		            System.out.println("Enter First Name: ");
		            String fname=sc.next();
		            System.out.println("Enter Middle Name: ");
		            String mname=sc.next();
		            System.out.println("Enter Last Name: ");
		            String lname=sc.next();
		            System.out.println("Enter Mobile No: ");
		            Long mno=sc.nextLong();
		            aut.setAuthorId(aid);
		            aut.setFirstName(fname);
		            aut.setMiddleName(mname);
		            aut.setLastName(lname);
		            aut.setPhoneNo(mno);
		            asi.addAuthor(aut);
		            System.out.println("Author details added successfully");
		            break;
			case 2:
				
				System.out.println("Enter AuthorId:");
				aid=sc.nextInt();
				System.out.println("Enter the field to update:");
				fname=sc.next();
				aut.setFirstName(fname);
				System.out.println("Enter lname:");
				lname=sc.next();
				aut.setLastName(lname);
				System.out.println("Enter phone no:");
				mno=sc.nextLong();
				aut.setPhoneNo(mno);
				asi.updateAuthor(aut);
				System.out.println("Details updated successfully");
				break;
	}
		}
}
}