package com.jpa.service;

import com.jpa.bean.Author;
import com.jpa.dao.AuthorDao;
import com.jpa.dao.AuthorDaoImpl;

public class AuthorServiceImpl implements AuthorService {

	@Override
	public Author getAuthorById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addAuthor(Author auth) {
		// TODO Auto-generated method stub
		AuthorDao ad=new AuthorDaoImpl();
		ad.addAuthor(auth);
	}

	@Override
	public void updateAuthor(Author auth) {
		// TODO Auto-generated method stub
		AuthorDao ad=new AuthorDaoImpl();
		ad.updateAuthor(auth);
	}

	@Override
	public void deleteAuthor() {
		// TODO Auto-generated method stub
		
	}

}
