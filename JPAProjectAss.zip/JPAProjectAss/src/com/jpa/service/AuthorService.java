package com.jpa.service;

import com.jpa.bean.Author;

public interface AuthorService {
	public Author getAuthorById(int id);
	public void addAuthor(Author auth);
	public void updateAuthor(Author auth);
	public void deleteAuthor();
}
