package com.jpa.dao;

import com.jpa.bean.Author;

public interface AuthorDao {
	public Author getAuthorById(int id);
	public void addAuthor(Author auth);
	public void updateAuthor(Author auth);
	public void deleteAuthor();
	

}
