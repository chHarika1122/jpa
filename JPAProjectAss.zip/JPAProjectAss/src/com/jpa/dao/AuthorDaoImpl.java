package com.jpa.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.jpa.bean.Author;


public class AuthorDaoImpl implements AuthorDao {

	@Override
	public void addAuthor(Author auth) {
		// TODO Auto-generated method stub
		
		EntityManagerFactory emf =null;
		EntityManager em = null;
try {
	    emf = Persistence.createEntityManagerFactory("JPAProjectAss");   
    em = emf.createEntityManager();  
em.getTransaction().begin();
em.persist(auth);
em.getTransaction().commit();
}catch(Exception ex) {
	
	ex.printStackTrace();
	
} finally {
	
	if(em!=null && emf!=null)
		em.close();
	emf.close();
	
}


}
	
	@Override
	public void updateAuthor(Author auth) {
		// TODO Auto-generated method stub
		int Id = 0;
		/*String lname;
		String fname;
		Long mobno;*/
		EntityManagerFactory emf =null;
		EntityManager em = null;
	try {

	
	emf = Persistence.createEntityManagerFactory("JPAProjectAss");  
	em = emf.createEntityManager(); 

	Author aut=em.find(Author.class, Id);
	if(aut!=null) {            
		em.getTransaction().begin();
		aut.getLastName();
		aut.getFirstName();
		aut.getPhoneNo();
		em.persist(aut);
		//em.merge(auth);
		em.getTransaction().commit();
	}
	else {
	System.out.println("aut details are not given");
	}

	}catch(Exception ex) {

	ex.printStackTrace();

	} finally {

	if(em!=null && emf!=null)
		em.close();
	emf.close();

	}


	}
	

	@Override
	public void deleteAuthor() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Author getAuthorById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
