package Service;

import Bean.Author;

public interface AuthorService {

	public abstract void addAuthor(Author auth);

	public abstract void updateAuthor(Author auth);

	public abstract void removeAuthor(Author auth);

	public abstract Author findAuthorById(int id);
}
