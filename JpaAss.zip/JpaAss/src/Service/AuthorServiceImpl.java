package Service;

import Bean.Author;
import Dao.AuthorDao;
import Dao.AuthorDaoImpl;

public class AuthorServiceImpl implements AuthorService{
	
	
	private AuthorDao dao;

	public AuthorServiceImpl() {
		dao = new AuthorDaoImpl();
	}

	@Override
	public void addAuthor(Author auth) {
		// TODO Auto-generated method stub
		dao.beginTransaction();
		dao.addAuthor(auth);
		dao.commitTransaction();
	}

	@Override
	public void updateAuthor(Author auth) {
		// TODO Auto-generated method stub
		dao.beginTransaction();
		dao.updateAuthor(auth);
		dao.commitTransaction();
	}

	@Override
	public void removeAuthor(Author auth) {
		// TODO Auto-generated method stub
		dao.beginTransaction();
		dao.removeAuthor(auth);
		dao.commitTransaction();
	}

	@Override
	public Author findAuthorById(int id) {
		// TODO Auto-generated method stub
		Author author  = dao.getAuthorById(id);
		return author;
		
	}
}
