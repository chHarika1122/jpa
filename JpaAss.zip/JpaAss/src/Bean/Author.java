package Bean;
import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
//import javax.persistence.Table;

@Entity
public class Author implements Serializable {
	
	private static final long serialVersionUID = 1L;
	@Id
	
	private Integer authId;
	private String fName;
	private String mname;
	private String lname;
	private Long mbno;
	public Integer getAuthId() {
		return authId;
	}
	public void setAuthId(Integer authId) {
		this.authId = authId;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public Long getMbno() {
		return mbno;
	}
	public void setMbno(Long mbno) {
		this.mbno = mbno;
	}
	
}
