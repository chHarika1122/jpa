package Dao;

import Bean.Author;

public interface AuthorDao {

	public abstract Author getAuthorById(int id);

	public abstract void addAuthor(Author auth);

	public abstract void removeAuthor(Author auth);

	public abstract void updateAuthor(Author auth);

	public abstract void commitTransaction();

	public abstract void beginTransaction();

}
