package Dao;

import javax.persistence.EntityManager;

import Bean.Author;

public class AuthorDaoImpl implements AuthorDao {

	private EntityManager entityManager;
	public AuthorDaoImpl() {
		entityManager = JPAutil.getEntityManager();
	}
	
	@Override
	public Author getAuthorById(int id) {
		// TODO Auto-generated method stub
		
		Author author = entityManager.find(Author.class, id);
		return author;
		
	}

	@Override
	public void addAuthor(Author auth) {
		// TODO Auto-generated method stub
		
		entityManager.persist(auth);
	}

	@Override
	public void removeAuthor(Author auth) {
		// TODO Auto-generated method stub
		entityManager.remove(auth);
	}

	@Override
	public void updateAuthor(Author auth) {
		// TODO Auto-generated method stub
		entityManager.merge(auth);
	}

	@Override
	public void beginTransaction() {
		// TODO Auto-generated method stub
		entityManager.getTransaction().begin();
	}

	@Override
	public void commitTransaction() {
		// TODO Auto-generated method stub
		entityManager.getTransaction().commit();
	}


}
